package com.vrm.rentalmanagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RentalmanagementsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
