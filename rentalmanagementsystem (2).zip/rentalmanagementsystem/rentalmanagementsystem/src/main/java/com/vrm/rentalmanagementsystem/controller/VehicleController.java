package com.vrm.rentalmanagementsystem.controller;

import com.vrm.rentalmanagementsystem.dto.VehicleRequest;
import com.vrm.rentalmanagementsystem.entity.Vehicle;
import com.vrm.rentalmanagementsystem.entity.VehicleType;
import com.vrm.rentalmanagementsystem.service.VehicleService;

import jakarta.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping("/api/vehicles")
public class VehicleController {

    private final VehicleService vehicleService;

    public VehicleController(VehicleService vehicleService) {
        this.vehicleService = vehicleService;
    }

    @GetMapping
    public ResponseEntity<List<Vehicle>> getAllVehicles() {

        return ResponseEntity.ok(
                vehicleService.getAllVehicles()
        );
    }

    @GetMapping("/{id}")
    public ResponseEntity<Vehicle> getVehicleById(
            @PathVariable Long id) {

        return ResponseEntity.ok(
                vehicleService.getVehicleById(id)
        );
    }

    @GetMapping("/search")
    public ResponseEntity<List<Vehicle>> searchVehicles(

            @RequestParam(required = false)
            String name,

            @RequestParam(required = false)
            VehicleType type,

            @RequestParam(required = false)
            String location,

            @RequestParam(required = false)
            BigDecimal minPrice,

            @RequestParam(required = false)
            BigDecimal maxPrice,

            @RequestParam(required = false)
            Boolean available) {

        return ResponseEntity.ok(
                vehicleService.searchVehicles(
                        name,
                        type,
                        location,
                        minPrice,
                        maxPrice,
                        available
                )
        );
    }

    @PostMapping
    public ResponseEntity<Vehicle> addVehicle(
            @Valid @RequestBody VehicleRequest request,
            Authentication authentication) {

        Vehicle vehicle = new Vehicle();

        vehicle.setName(request.getName());
        vehicle.setDescription(request.getDescription());
        vehicle.setImage(request.getImage());
        vehicle.setType(request.getType());
        vehicle.setRegistrationNumber(
                request.getRegistrationNumber()
        );
        vehicle.setDailyPrice(request.getDailyPrice());
        vehicle.setLocation(request.getLocation());
        vehicle.setAvailable(request.isAvailable());
        vehicle.setFeatures(request.getFeatures());

        Vehicle savedVehicle =
                vehicleService.addVehicle(
                        vehicle,
                        authentication.getName()
                );

        return ResponseEntity.ok(savedVehicle);
    }

    @GetMapping("/owner/my")
    public ResponseEntity<List<Vehicle>> getMyVehicles(
            Authentication authentication) {

        return ResponseEntity.ok(
                vehicleService.getOwnerVehicles(
                        authentication.getName()
                )
        );
    }

    @PutMapping("/{id}")
    public ResponseEntity<Vehicle> updateVehicle(
            @PathVariable Long id,
            @Valid @RequestBody VehicleRequest request,
            Authentication authentication) {

        Vehicle vehicle = new Vehicle();

        vehicle.setName(request.getName());
        vehicle.setDescription(request.getDescription());
        vehicle.setImage(request.getImage());
        vehicle.setType(request.getType());
        vehicle.setRegistrationNumber(
                request.getRegistrationNumber()
        );
        vehicle.setDailyPrice(request.getDailyPrice());
        vehicle.setLocation(request.getLocation());
        vehicle.setAvailable(request.isAvailable());
        vehicle.setFeatures(request.getFeatures());

        return ResponseEntity.ok(
                vehicleService.updateVehicle(
                        id,
                        vehicle,
                        authentication.getName()
                )
        );
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteVehicle(
            @PathVariable Long id,
            Authentication authentication) {

        vehicleService.deleteVehicle(
                id,
                authentication.getName()
        );

        return ResponseEntity.ok(
                "Vehicle deleted successfully"
        );
    }

    @PutMapping("/{id}/availability")
    public ResponseEntity<Vehicle> changeAvailability(
            @PathVariable Long id,
            @RequestParam boolean available,
            Authentication authentication) {

        return ResponseEntity.ok(
                vehicleService.changeAvailability(
                        id,
                        available,
                        authentication.getName()
                )
        );
    }
}