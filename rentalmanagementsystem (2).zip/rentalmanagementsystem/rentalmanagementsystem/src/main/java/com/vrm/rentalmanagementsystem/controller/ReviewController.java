package com.vrm.rentalmanagementsystem.controller;

import com.vrm.rentalmanagementsystem.dto.ReviewRequest;
import com.vrm.rentalmanagementsystem.entity.Review;
import com.vrm.rentalmanagementsystem.service.ReviewService;

import jakarta.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/reviews")
public class ReviewController {

    private final ReviewService reviewService;

    public ReviewController(ReviewService reviewService) {
        this.reviewService = reviewService;
    }

    // Add review
    @PostMapping
    public ResponseEntity<Review> addReview(
            @Valid @RequestBody ReviewRequest request,
            Authentication authentication) {

        Review review = reviewService.addReview(
                request.getVehicleId(),
                request.getRating(),
                request.getComment(),
                authentication.getName()
        );

        return ResponseEntity.ok(review);
    }

    // Get reviews for vehicle
    @GetMapping("/vehicle/{vehicleId}")
    public ResponseEntity<List<Review>> getVehicleReviews(
            @PathVariable Long vehicleId) {

        return ResponseEntity.ok(
                reviewService.getVehicleReviews(vehicleId)
        );
    }

    // Update own review
    @PutMapping("/{reviewId}")
    public ResponseEntity<Review> updateReview(
            @PathVariable Long reviewId,
            @Valid @RequestBody ReviewRequest request,
            Authentication authentication) {

        Review review = reviewService.updateReview(
                reviewId,
                request.getRating(),
                request.getComment(),
                authentication.getName()
        );

        return ResponseEntity.ok(review);
    }

    // Average rating
    @GetMapping("/vehicle/{vehicleId}/average")
    public ResponseEntity<Double> getAverageRating(
            @PathVariable Long vehicleId) {

        return ResponseEntity.ok(
                reviewService.getAverageRating(vehicleId)
        );
    }

    // Review count
    @GetMapping("/vehicle/{vehicleId}/count")
    public ResponseEntity<Long> getReviewCount(
            @PathVariable Long vehicleId) {

        return ResponseEntity.ok(
                reviewService.getReviewCount(vehicleId)
        );
    }
}