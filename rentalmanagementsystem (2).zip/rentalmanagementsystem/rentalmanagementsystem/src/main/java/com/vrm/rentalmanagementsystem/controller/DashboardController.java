package com.vrm.rentalmanagementsystem.controller;

import com.vrm.rentalmanagementsystem.dto.CustomerDashboardResponse;
import com.vrm.rentalmanagementsystem.dto.OwnerDashboardResponse;
import com.vrm.rentalmanagementsystem.entity.Booking;
import com.vrm.rentalmanagementsystem.entity.BookingStatus;
import com.vrm.rentalmanagementsystem.entity.User;
import com.vrm.rentalmanagementsystem.service.BookingService;
import com.vrm.rentalmanagementsystem.service.UserService;
import com.vrm.rentalmanagementsystem.service.VehicleService;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {

    private final BookingService bookingService;
    private final VehicleService vehicleService;
    private final UserService userService;

    public DashboardController(
            BookingService bookingService,
            VehicleService vehicleService,
            UserService userService) {

        this.bookingService = bookingService;
        this.vehicleService = vehicleService;
        this.userService = userService;
    }

    // Customer Dashboard
    @GetMapping("/customer")
    public ResponseEntity<CustomerDashboardResponse> customerDashboard(
            Authentication authentication) {

        List<Booking> bookings =
                bookingService.getCustomerBookings(
                        authentication.getName()
                );

        long totalBookings = bookings.size();

        long upcomingBookings = bookings.stream()
                .filter(booking ->
                        booking.getStartDate()
                                .isAfter(java.time.LocalDate.now())
                        && booking.getStatus() != BookingStatus.CANCELLED
                        && booking.getStatus() != BookingStatus.REJECTED
                )
                .count();

        long completedBookings = bookings.stream()
                .filter(booking ->
                        booking.getStatus()
                                == BookingStatus.RETURNED
                )
                .count();

        long cancelledBookings = bookings.stream()
                .filter(booking ->
                        booking.getStatus()
                                == BookingStatus.CANCELLED
                )
                .count();

        CustomerDashboardResponse response =
                new CustomerDashboardResponse(
                        totalBookings,
                        upcomingBookings,
                        completedBookings,
                        cancelledBookings
                );

        return ResponseEntity.ok(response);
    }

    // Owner Dashboard
    @GetMapping("/owner")
    public ResponseEntity<OwnerDashboardResponse> ownerDashboard(
            Authentication authentication) {

        User owner =
                userService.findByEmail(
                        authentication.getName()
                );

        long totalVehicles =
                vehicleService
                        .getOwnerVehicles(
                                owner.getEmail()
                        )
                        .size();

        List<Booking> bookings =
                bookingService.getOwnerBookings(
                        owner.getEmail()
                );

        long totalBookings = bookings.size();

        long pendingBookings = bookings.stream()
                .filter(booking ->
                        booking.getStatus()
                                == BookingStatus.PENDING
                )
                .count();

        long completedBookings = bookings.stream()
                .filter(booking ->
                        booking.getStatus()
                                == BookingStatus.RETURNED
                )
                .count();

        OwnerDashboardResponse response =
                new OwnerDashboardResponse(
                        totalVehicles,
                        totalBookings,
                        pendingBookings,
                        completedBookings
                );

        return ResponseEntity.ok(response);
    }
}