package com.vrm.rentalmanagementsystem.entity;

public enum Role {
    CUSTOMER,
    OWNER
}