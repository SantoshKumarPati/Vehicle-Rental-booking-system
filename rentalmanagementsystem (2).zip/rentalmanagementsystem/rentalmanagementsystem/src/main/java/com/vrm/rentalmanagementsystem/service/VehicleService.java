package com.vrm.rentalmanagementsystem.service;

import com.vrm.rentalmanagementsystem.entity.User;
import com.vrm.rentalmanagementsystem.entity.Vehicle;
import com.vrm.rentalmanagementsystem.entity.VehicleType;
import com.vrm.rentalmanagementsystem.repository.VehicleRepository;

import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
public class VehicleService {

    private final VehicleRepository vehicleRepository;
    private final UserService userService;

    public VehicleService(
            VehicleRepository vehicleRepository,
            UserService userService) {

        this.vehicleRepository = vehicleRepository;
        this.userService = userService;
    }

    public Vehicle addVehicle(
            Vehicle vehicle,
            String ownerEmail) {

        User owner =
                userService.findByEmail(ownerEmail);

        vehicle.setOwner(owner);
        vehicle.setAvailable(true);

        return vehicleRepository.save(vehicle);
    }

    public List<Vehicle> getAllVehicles() {

        return vehicleRepository.findAll();
    }

    public Vehicle getVehicleById(Long id) {

        return vehicleRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Vehicle not found"
                        ));
    }

    public List<Vehicle> getOwnerVehicles(
            String ownerEmail) {

        User owner =
                userService.findByEmail(ownerEmail);

        return vehicleRepository.findByOwner(owner);
    }

    public Vehicle updateVehicle(
            Long id,
            Vehicle updatedVehicle,
            String ownerEmail) {

        Vehicle vehicle =
                getVehicleById(id);

        if (!vehicle.getOwner()
                .getEmail()
                .equals(ownerEmail)) {

            throw new RuntimeException(
                    "You can update only your own vehicle"
            );
        }

        vehicle.setName(
                updatedVehicle.getName()
        );

        vehicle.setDescription(
                updatedVehicle.getDescription()
        );

        vehicle.setImage(
                updatedVehicle.getImage()
        );

        vehicle.setType(
                updatedVehicle.getType()
        );

        vehicle.setRegistrationNumber(
                updatedVehicle.getRegistrationNumber()
        );

        vehicle.setDailyPrice(
                updatedVehicle.getDailyPrice()
        );

        vehicle.setLocation(
                updatedVehicle.getLocation()
        );

        vehicle.setAvailable(
                updatedVehicle.isAvailable()
        );

        vehicle.setFeatures(
                updatedVehicle.getFeatures()
        );

        return vehicleRepository.save(vehicle);
    }

    public void deleteVehicle(
            Long id,
            String ownerEmail) {

        Vehicle vehicle =
                getVehicleById(id);

        if (!vehicle.getOwner()
                .getEmail()
                .equals(ownerEmail)) {

            throw new RuntimeException(
                    "You can delete only your own vehicle"
            );
        }

        if (vehicle.getBookings() != null
                && !vehicle.getBookings().isEmpty()) {

            throw new RuntimeException(
                    "Vehicle cannot be deleted because it has bookings"
            );
        }

        vehicleRepository.delete(vehicle);
    }

    public List<Vehicle> searchVehicles(
            String name,
            VehicleType type,
            String location,
            BigDecimal minPrice,
            BigDecimal maxPrice,
            Boolean available) {

        List<Vehicle> vehicles =
                vehicleRepository.findAll();

        return vehicles.stream()
                .filter(vehicle ->
                        name == null
                                || name.isBlank()
                                || vehicle.getName()
                                .toLowerCase()
                                .contains(
                                        name.toLowerCase()
                                )
                )
                .filter(vehicle ->
                        type == null
                                || vehicle.getType() == type
                )
                .filter(vehicle ->
                        location == null
                                || location.isBlank()
                                || vehicle.getLocation()
                                .toLowerCase()
                                .contains(
                                        location.toLowerCase()
                                )
                )
                .filter(vehicle ->
                        minPrice == null
                                || vehicle.getDailyPrice()
                                .compareTo(minPrice) >= 0
                )
                .filter(vehicle ->
                        maxPrice == null
                                || vehicle.getDailyPrice()
                                .compareTo(maxPrice) <= 0
                )
                .filter(vehicle ->
                        available == null
                                || vehicle.isAvailable()
                                == available
                )
                .toList();
    }

    public Vehicle changeAvailability(
            Long id,
            boolean available,
            String ownerEmail) {

        Vehicle vehicle =
                getVehicleById(id);

        if (!vehicle.getOwner()
                .getEmail()
                .equals(ownerEmail)) {

            throw new RuntimeException(
                    "You can change availability only for your own vehicle"
            );
        }

        vehicle.setAvailable(available);

        return vehicleRepository.save(vehicle);
    }
}