package com.vrm.rentalmanagementsystem.repository;

import com.vrm.rentalmanagementsystem.entity.Booking;
import com.vrm.rentalmanagementsystem.entity.BookingStatus;
import com.vrm.rentalmanagementsystem.entity.User;
import com.vrm.rentalmanagementsystem.entity.Vehicle;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface BookingRepository extends JpaRepository<Booking, Long> {

    List<Booking> findByCustomerOrderByStartDateDesc(User customer);

    List<Booking> findByVehicleOrderByStartDateDesc(Vehicle vehicle);

    List<Booking> findByVehicle_OwnerOrderByStartDateDesc(User owner);

    @Query("""
        SELECT b FROM Booking b
        WHERE b.vehicle.id = :vehicleId
        AND b.status IN :statuses
        AND b.startDate <= :endDate
        AND b.endDate >= :startDate
        """)
    List<Booking> findOverlappingBookings(
            @Param("vehicleId") Long vehicleId,
            @Param("startDate") LocalDate startDate,
            @Param("endDate") LocalDate endDate,
            @Param("statuses") List<BookingStatus> statuses
    );
}