package com.vrm.rentalmanagementsystem.service;

import com.vrm.rentalmanagementsystem.entity.Booking;
import com.vrm.rentalmanagementsystem.entity.BookingStatus;
import com.vrm.rentalmanagementsystem.entity.User;
import com.vrm.rentalmanagementsystem.entity.Vehicle;
import com.vrm.rentalmanagementsystem.repository.BookingRepository;
import com.vrm.rentalmanagementsystem.repository.VehicleRepository;

import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
public class BookingService {

    private final BookingRepository bookingRepository;
    private final VehicleRepository vehicleRepository;
    private final UserService userService;

    public BookingService(
            BookingRepository bookingRepository,
            VehicleRepository vehicleRepository,
            UserService userService) {

        this.bookingRepository = bookingRepository;
        this.vehicleRepository = vehicleRepository;
        this.userService = userService;
    }

    // Create booking
    public Booking createBooking(
            Long vehicleId,
            LocalDate startDate,
            LocalDate endDate,
            String customerEmail) {

        if (endDate.isBefore(startDate)) {
            throw new RuntimeException(
                    "End date cannot be before start date");
        }

        Vehicle vehicle = vehicleRepository.findById(vehicleId)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Vehicle not found"));

        if (!vehicle.isAvailable()) {
            throw new RuntimeException(
                    "Vehicle is currently unavailable");
        }

        List<BookingStatus> activeStatuses = List.of(
                BookingStatus.PENDING,
                BookingStatus.APPROVED,
                BookingStatus.HANDED_OVER
        );

        List<Booking> overlappingBookings =
                bookingRepository.findOverlappingBookings(
                        vehicleId,
                        startDate,
                        endDate,
                        activeStatuses
                );

        if (!overlappingBookings.isEmpty()) {
            throw new RuntimeException(
                    "Vehicle is already booked for the selected dates");
        }

        User customer =
                userService.findByEmail(customerEmail);

        long totalDays =
                ChronoUnit.DAYS.between(
                        startDate,
                        endDate
                ) + 1;

        BigDecimal totalCost =
                vehicle.getDailyPrice().multiply(
                        BigDecimal.valueOf(totalDays)
                );

        Booking booking = new Booking();

        booking.setVehicle(vehicle);
        booking.setCustomer(customer);
        booking.setStartDate(startDate);
        booking.setEndDate(endDate);
        booking.setTotalDays(totalDays);
        booking.setTotalCost(totalCost);
        booking.setStatus(BookingStatus.PENDING);
        booking.setCreatedAt(LocalDateTime.now());

        return bookingRepository.save(booking);
    }

    // Customer bookings
    public List<Booking> getCustomerBookings(
            String customerEmail) {

        User customer =
                userService.findByEmail(customerEmail);

        return bookingRepository
                .findByCustomerOrderByStartDateDesc(customer);
    }

    // Owner bookings
    public List<Booking> getOwnerBookings(
            String ownerEmail) {

        User owner =
                userService.findByEmail(ownerEmail);

        return bookingRepository
                .findByVehicle_OwnerOrderByStartDateDesc(owner);
    }

    // Get booking by ID
    public Booking getBookingById(Long id) {

        return bookingRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Booking not found"));
    }

    // Approve booking
    public Booking approveBooking(
            Long id,
            String ownerEmail) {

        Booking booking = getBookingById(id);

        checkOwner(booking, ownerEmail);

        if (booking.getStatus() != BookingStatus.PENDING) {
            throw new RuntimeException(
                    "Only pending bookings can be approved");
        }

        booking.setStatus(BookingStatus.APPROVED);

        return bookingRepository.save(booking);
    }

    // Reject booking
    public Booking rejectBooking(
            Long id,
            String ownerEmail) {

        Booking booking = getBookingById(id);

        checkOwner(booking, ownerEmail);

        if (booking.getStatus() != BookingStatus.PENDING) {
            throw new RuntimeException(
                    "Only pending bookings can be rejected");
        }

        booking.setStatus(BookingStatus.REJECTED);

        return bookingRepository.save(booking);
    }

    // Cancel booking
    public Booking cancelBooking(
            Long id,
            String customerEmail) {

        Booking booking = getBookingById(id);

        if (!booking.getCustomer()
                .getEmail()
                .equals(customerEmail)) {

            throw new RuntimeException(
                    "You can cancel only your own booking");
        }

        if (booking.getStatus() != BookingStatus.PENDING
                && booking.getStatus() != BookingStatus.APPROVED) {

            throw new RuntimeException(
                    "This booking cannot be cancelled");
        }

        booking.setStatus(BookingStatus.CANCELLED);

        return bookingRepository.save(booking);
    }

    // Handover vehicle
    public Booking handoverVehicle(
            Long id,
            String ownerEmail) {

        Booking booking = getBookingById(id);

        checkOwner(booking, ownerEmail);

        if (booking.getStatus() != BookingStatus.APPROVED) {
            throw new RuntimeException(
                    "Only approved bookings can be handed over");
        }

        booking.setStatus(BookingStatus.HANDED_OVER);

        return bookingRepository.save(booking);
    }

    // Return vehicle
    public Booking returnVehicle(
            Long id,
            String ownerEmail) {

        Booking booking = getBookingById(id);

        checkOwner(booking, ownerEmail);

        if (booking.getStatus() != BookingStatus.HANDED_OVER) {
            throw new RuntimeException(
                    "Only handed-over bookings can be returned");
        }

        booking.setStatus(BookingStatus.RETURNED);

        return bookingRepository.save(booking);
    }

    // Check whether the logged-in owner owns the booking's vehicle
    private void checkOwner(
            Booking booking,
            String ownerEmail) {

        if (!booking.getVehicle()
                .getOwner()
                .getEmail()
                .equals(ownerEmail)) {

            throw new RuntimeException(
                    "You can manage only your vehicle bookings");
        }
    }
}