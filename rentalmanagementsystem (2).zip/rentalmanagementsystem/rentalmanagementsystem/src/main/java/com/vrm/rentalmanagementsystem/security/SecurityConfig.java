package com.vrm.rentalmanagementsystem.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtAuthenticationFilter;
    private final CustomUserDetailsService userDetailsService;

    public SecurityConfig(
            JwtAuthenticationFilter jwtAuthenticationFilter,
            CustomUserDetailsService userDetailsService) {

        this.jwtAuthenticationFilter = jwtAuthenticationFilter;
        this.userDetailsService = userDetailsService;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationProvider authenticationProvider() {

        DaoAuthenticationProvider provider =
                new DaoAuthenticationProvider(userDetailsService);

        provider.setPasswordEncoder(passwordEncoder());

        return provider;
    }

    @Bean
    public AuthenticationManager authenticationManager(
            AuthenticationConfiguration configuration)
            throws Exception {

        return configuration.getAuthenticationManager();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(
            HttpSecurity http)
            throws Exception {

        http
                .csrf(csrf -> csrf.disable())
                .cors(cors -> {})
                .sessionManagement(session ->
                        session.sessionCreationPolicy(
                                SessionCreationPolicy.STATELESS
                        )
                )
                .authorizeHttpRequests(auth -> auth

                        .requestMatchers(
                                HttpMethod.OPTIONS,
                                "/**"
                        ).permitAll()

                        .requestMatchers(
                                "/api/auth/**",
                                "/api/auth/login",
                                "/api/auth/register",
                                "/error"
                        ).permitAll()

                        .requestMatchers(
                                HttpMethod.POST,
                                "/api/vehicles"
                        ).hasRole("OWNER")

                        .requestMatchers(
                                HttpMethod.PUT,
                                "/api/vehicles/*"
                        ).hasRole("OWNER")

                        .requestMatchers(
                                HttpMethod.DELETE,
                                "/api/vehicles/*"
                        ).hasRole("OWNER")

                        .requestMatchers(
                                HttpMethod.PUT,
                                "/api/vehicles/*/availability"
                        ).hasRole("OWNER")

                        .requestMatchers(
                                "/api/vehicles/owner/**"
                        ).hasRole("OWNER")

                        .requestMatchers(
                                "/api/bookings/owner"
                        ).hasRole("OWNER")

                        .requestMatchers(
                                "/api/bookings/*/approve"
                        ).hasRole("OWNER")

                        .requestMatchers(
                                "/api/bookings/*/reject"
                        ).hasRole("OWNER")

                        .requestMatchers(
                                "/api/bookings/*/handover"
                        ).hasRole("OWNER")

                        .requestMatchers(
                                "/api/bookings/*/return"
                        ).hasRole("OWNER")

                        .requestMatchers(
                                "/api/dashboard/owner"
                        ).hasRole("OWNER")

                        .requestMatchers(
                                HttpMethod.POST,
                                "/api/bookings"
                        ).hasRole("CUSTOMER")

                        .requestMatchers(
                                "/api/bookings/my"
                        ).hasRole("CUSTOMER")

                        .requestMatchers(
                                "/api/bookings/*/cancel"
                        ).hasRole("CUSTOMER")

                        .requestMatchers(
                                HttpMethod.POST,
                                "/api/reviews"
                        ).hasRole("CUSTOMER")

                        .requestMatchers(
                                HttpMethod.PUT,
                                "/api/reviews/*"
                        ).hasRole("CUSTOMER")

                        .requestMatchers(
                                "/api/dashboard/customer"
                        ).hasRole("CUSTOMER")

                        .requestMatchers(
                                HttpMethod.GET,
                                "/api/vehicles",
                                "/api/vehicles/*",
                                "/api/vehicles/search"
                        ).authenticated()

                        .requestMatchers(
                                HttpMethod.GET,
                                "/api/reviews/**"
                        ).authenticated()

                        .requestMatchers(
                                HttpMethod.GET,
                                "/api/bookings/*"
                        ).authenticated()

                        .anyRequest().authenticated()
                )
                .authenticationProvider(
                        authenticationProvider()
                )
                .addFilterBefore(
                        jwtAuthenticationFilter,
                        UsernamePasswordAuthenticationFilter.class
                );

        return http.build();
    }
}