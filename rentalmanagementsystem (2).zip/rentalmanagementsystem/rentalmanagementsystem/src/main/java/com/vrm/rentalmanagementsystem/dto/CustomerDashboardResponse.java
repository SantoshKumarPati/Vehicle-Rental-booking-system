package com.vrm.rentalmanagementsystem.dto;

public class CustomerDashboardResponse {

    private long totalBookings;
    private long upcomingBookings;
    private long completedBookings;
    private long cancelledBookings;

    public CustomerDashboardResponse(
            long totalBookings,
            long upcomingBookings,
            long completedBookings,
            long cancelledBookings) {

        this.totalBookings = totalBookings;
        this.upcomingBookings = upcomingBookings;
        this.completedBookings = completedBookings;
        this.cancelledBookings = cancelledBookings;
    }

    public long getTotalBookings() {
        return totalBookings;
    }

    public long getUpcomingBookings() {
        return upcomingBookings;
    }

    public long getCompletedBookings() {
        return completedBookings;
    }

    public long getCancelledBookings() {
        return cancelledBookings;
    }
}