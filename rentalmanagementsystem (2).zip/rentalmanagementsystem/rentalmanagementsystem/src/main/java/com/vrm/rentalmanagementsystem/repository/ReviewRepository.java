package com.vrm.rentalmanagementsystem.repository;

import com.vrm.rentalmanagementsystem.entity.Review;
import com.vrm.rentalmanagementsystem.entity.User;
import com.vrm.rentalmanagementsystem.entity.Vehicle;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface ReviewRepository extends JpaRepository<Review, Long> {

    List<Review> findByVehicleOrderByCreatedAtDesc(Vehicle vehicle);

    Optional<Review> findByVehicleAndCustomer(Vehicle vehicle, User customer);

    @Query("""
        SELECT COALESCE(AVG(r.rating), 0)
        FROM Review r
        WHERE r.vehicle.id = :vehicleId
        """)
    Double getAverageRating(Long vehicleId);

    long countByVehicle(Vehicle vehicle);
}