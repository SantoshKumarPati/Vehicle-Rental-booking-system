package com.vrm.rentalmanagementsystem.repository;

import com.vrm.rentalmanagementsystem.entity.Vehicle;
import com.vrm.rentalmanagementsystem.entity.VehicleType;
import com.vrm.rentalmanagementsystem.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface VehicleRepository extends JpaRepository<Vehicle, Long> {

    List<Vehicle> findByOwner(User owner);

    List<Vehicle> findByType(VehicleType type);

    List<Vehicle> findByLocationContainingIgnoreCase(String location);

    Optional<Vehicle> findByRegistrationNumber(String registrationNumber);
}