package com.vrm.rentalmanagementsystem.entity;

public enum VehicleType {
    CAR,
    SUV,
    BIKE,
    VAN
}