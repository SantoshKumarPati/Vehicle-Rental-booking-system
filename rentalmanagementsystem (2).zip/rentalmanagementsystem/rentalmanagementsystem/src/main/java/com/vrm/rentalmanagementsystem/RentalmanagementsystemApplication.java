package com.vrm.rentalmanagementsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RentalmanagementsystemApplication {

    public static void main(String[] args) {

        SpringApplication.run(
                RentalmanagementsystemApplication.class,
                args
        );
    }
}