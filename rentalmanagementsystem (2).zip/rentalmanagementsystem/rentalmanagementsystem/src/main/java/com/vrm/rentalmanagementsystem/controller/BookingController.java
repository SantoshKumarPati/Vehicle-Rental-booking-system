package com.vrm.rentalmanagementsystem.controller;

import com.vrm.rentalmanagementsystem.dto.BookingRequest;
import com.vrm.rentalmanagementsystem.entity.Booking;
import com.vrm.rentalmanagementsystem.service.BookingService;

import jakarta.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {

    private final BookingService bookingService;

    public BookingController(BookingService bookingService) {
        this.bookingService = bookingService;
    }

    @PostMapping
    public ResponseEntity<Booking> createBooking(
            @Valid @RequestBody BookingRequest request,
            Authentication authentication) {

        Booking booking = bookingService.createBooking(
                request.getVehicleId(),
                request.getStartDate(),
                request.getEndDate(),
                authentication.getName()
        );

        return ResponseEntity.ok(booking);
    }

    @GetMapping("/my")
    public ResponseEntity<List<Booking>> getMyBookings(
            Authentication authentication) {

        return ResponseEntity.ok(
                bookingService.getCustomerBookings(
                        authentication.getName()
                )
        );
    }

    @GetMapping("/owner")
    public ResponseEntity<List<Booking>> getOwnerBookings(
            Authentication authentication) {

        return ResponseEntity.ok(
                bookingService.getOwnerBookings(
                        authentication.getName()
                )
        );
    }

    @GetMapping("/{id}")
    public ResponseEntity<Booking> getBookingById(
            @PathVariable Long id) {

        return ResponseEntity.ok(
                bookingService.getBookingById(id)
        );
    }

    @PutMapping("/{id}/approve")
    public ResponseEntity<Booking> approveBooking(
            @PathVariable Long id,
            Authentication authentication) {

        Booking booking = bookingService.approveBooking(
                id,
                authentication.getName()
        );

        return ResponseEntity.ok(booking);
    }

    @PutMapping("/{id}/reject")
    public ResponseEntity<Booking> rejectBooking(
            @PathVariable Long id,
            Authentication authentication) {

        Booking booking = bookingService.rejectBooking(
                id,
                authentication.getName()
        );

        return ResponseEntity.ok(booking);
    }

    @PutMapping("/{id}/cancel")
    public ResponseEntity<Booking> cancelBooking(
            @PathVariable Long id,
            Authentication authentication) {

        Booking booking = bookingService.cancelBooking(
                id,
                authentication.getName()
        );

        return ResponseEntity.ok(booking);
    }

    @PutMapping("/{id}/handover")
    public ResponseEntity<Booking> handoverVehicle(
            @PathVariable Long id,
            Authentication authentication) {

        Booking booking = bookingService.handoverVehicle(
                id,
                authentication.getName()
        );

        return ResponseEntity.ok(booking);
    }

    @PutMapping("/{id}/return")
    public ResponseEntity<Booking> returnVehicle(
            @PathVariable Long id,
            Authentication authentication) {

        Booking booking = bookingService.returnVehicle(
                id,
                authentication.getName()
        );

        return ResponseEntity.ok(booking);
    }
}