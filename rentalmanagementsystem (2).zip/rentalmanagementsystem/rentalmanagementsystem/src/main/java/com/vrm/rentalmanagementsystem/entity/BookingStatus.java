package com.vrm.rentalmanagementsystem.entity;

public enum BookingStatus {
    PENDING,
    APPROVED,
    REJECTED,
    HANDED_OVER,
    RETURNED,
    CANCELLED
}