package com.vrm.rentalmanagementsystem.dto;

public class OwnerDashboardResponse {

    private long totalVehicles;
    private long totalBookings;
    private long pendingBookings;
    private long completedBookings;

    public OwnerDashboardResponse(
            long totalVehicles,
            long totalBookings,
            long pendingBookings,
            long completedBookings) {

        this.totalVehicles = totalVehicles;
        this.totalBookings = totalBookings;
        this.pendingBookings = pendingBookings;
        this.completedBookings = completedBookings;
    }

    public long getTotalVehicles() {
        return totalVehicles;
    }

    public long getTotalBookings() {
        return totalBookings;
    }

    public long getPendingBookings() {
        return pendingBookings;
    }

    public long getCompletedBookings() {
        return completedBookings;
    }
}