package com.vrm.rentalmanagementsystem.service;

import com.vrm.rentalmanagementsystem.entity.Booking;
import com.vrm.rentalmanagementsystem.entity.BookingStatus;
import com.vrm.rentalmanagementsystem.entity.Review;
import com.vrm.rentalmanagementsystem.entity.User;
import com.vrm.rentalmanagementsystem.entity.Vehicle;
import com.vrm.rentalmanagementsystem.repository.BookingRepository;
import com.vrm.rentalmanagementsystem.repository.ReviewRepository;
import com.vrm.rentalmanagementsystem.repository.VehicleRepository;

import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ReviewService {

    private final ReviewRepository reviewRepository;
    private final VehicleRepository vehicleRepository;
    private final BookingRepository bookingRepository;
    private final UserService userService;

    public ReviewService(
            ReviewRepository reviewRepository,
            VehicleRepository vehicleRepository,
            BookingRepository bookingRepository,
            UserService userService) {

        this.reviewRepository = reviewRepository;
        this.vehicleRepository = vehicleRepository;
        this.bookingRepository = bookingRepository;
        this.userService = userService;
    }

    // Add review
    public Review addReview(
            Long vehicleId,
            int rating,
            String comment,
            String customerEmail) {

        if (rating < 1 || rating > 5) {
            throw new RuntimeException(
                    "Rating must be between 1 and 5");
        }

        User customer =
                userService.findByEmail(customerEmail);

        Vehicle vehicle =
                vehicleRepository.findById(vehicleId)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Vehicle not found"));

        // Check if customer already reviewed this vehicle
        if (reviewRepository
                .findByVehicleAndCustomer(vehicle, customer)
                .isPresent()) {

            throw new RuntimeException(
                    "You have already reviewed this vehicle");
        }

        // Customer must have a completed rental
        List<Booking> bookings =
                bookingRepository.findByCustomerOrderByStartDateDesc(
                        customer
                );

        boolean completedRental = bookings.stream()
                .anyMatch(booking ->
                        booking.getVehicle().getId().equals(vehicleId)
                                && booking.getStatus()
                                == BookingStatus.RETURNED
                );

        if (!completedRental) {
            throw new RuntimeException(
                    "You can review only after completing a rental");
        }

        Review review = new Review();

        review.setVehicle(vehicle);
        review.setCustomer(customer);
        review.setRating(rating);
        review.setComment(comment);
        review.setCreatedAt(LocalDateTime.now());

        return reviewRepository.save(review);
    }

    // Get reviews for vehicle
    public List<Review> getVehicleReviews(
            Long vehicleId) {

        Vehicle vehicle =
                vehicleRepository.findById(vehicleId)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Vehicle not found"));

        return reviewRepository
                .findByVehicleOrderByCreatedAtDesc(vehicle);
    }

    // Update own review
    public Review updateReview(
            Long reviewId,
            int rating,
            String comment,
            String customerEmail) {

        if (rating < 1 || rating > 5) {
            throw new RuntimeException(
                    "Rating must be between 1 and 5");
        }

        Review review =
                reviewRepository.findById(reviewId)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Review not found"));

        if (!review.getCustomer()
                .getEmail()
                .equals(customerEmail)) {

            throw new RuntimeException(
                    "You can update only your own review");
        }

        review.setRating(rating);
        review.setComment(comment);
        review.setUpdatedAt(LocalDateTime.now());

        return reviewRepository.save(review);
    }

    // Average rating
    public Double getAverageRating(Long vehicleId) {

        return reviewRepository
                .getAverageRating(vehicleId);
    }

    // Review count
    public long getReviewCount(Long vehicleId) {

        Vehicle vehicle =
                vehicleRepository.findById(vehicleId)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Vehicle not found"));

        return reviewRepository.countByVehicle(vehicle);
    }
}