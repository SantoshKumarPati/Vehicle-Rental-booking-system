const API_BASE_URL = "http://127.0.0.1:8081/api";

function getToken() {
    return localStorage.getItem("token");
}

function getUserRole() {
    return localStorage.getItem("role");
}

function getUserName() {
    return localStorage.getItem("name");
}

function isLoggedIn() {
    return getToken() !== null;
}

function getAuthHeaders() {
    return {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + getToken()
    };
}

function logout() {
    localStorage.removeItem("token");
    localStorage.removeItem("name");
    localStorage.removeItem("email");
    localStorage.removeItem("role");

    window.location.href = "index.html";
}

function openDashboard() {
    const role = getUserRole();

    if (role === "OWNER") {
        window.location.href = "owner-dashboard.html";
    }
    else if (role === "CUSTOMER") {
        window.location.href = "customer-dashboard.html";
    }
    else {
        window.location.href = "login.html";
    }
}

function updateNavbar() {
    const loggedIn = isLoggedIn();

    const loginLink = document.getElementById("loginLink");
    const registerLink = document.getElementById("registerLink");
    const dashboardLink = document.getElementById("dashboardLink");
    const logoutLink = document.getElementById("logoutLink");

    if (loggedIn) {
        if (loginLink) {
            loginLink.classList.add("d-none");
        }

        if (registerLink) {
            registerLink.classList.add("d-none");
        }

        if (dashboardLink) {
            dashboardLink.classList.remove("d-none");
        }

        if (logoutLink) {
            logoutLink.classList.remove("d-none");
        }
    }
    else {
        if (loginLink) {
            loginLink.classList.remove("d-none");
        }

        if (registerLink) {
            registerLink.classList.remove("d-none");
        }

        if (dashboardLink) {
            dashboardLink.classList.add("d-none");
        }

        if (logoutLink) {
            logoutLink.classList.add("d-none");
        }
    }
}

function requireLogin() {
    if (!isLoggedIn()) {
        alert("Please login first.");
        window.location.href = "login.html";
        return false;
    }

    return true;
}

document.addEventListener("DOMContentLoaded", function () {
    updateNavbar();
});