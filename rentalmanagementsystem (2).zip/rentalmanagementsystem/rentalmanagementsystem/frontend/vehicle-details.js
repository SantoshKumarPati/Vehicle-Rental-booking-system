const params =
    new URLSearchParams(window.location.search);

const vehicleId =
    params.get("id");


async function loadVehicle() {

    const container =
        document.getElementById("vehicleDetails");


    if (!vehicleId) {

        container.innerHTML =
            `<div class="alert alert-danger">
                Vehicle ID is missing.
            </div>`;

        return;
    }


    try {

        const response = await fetch(
            API_BASE_URL + "/vehicles/" + vehicleId,
            {
                headers: getAuthHeaders()
            }
        );


        const vehicle =
            await response.json();


        if (!response.ok) {

            throw new Error();
        }


        const image =
            vehicle.image ||
            "https://via.placeholder.com/700x400?text=Vehicle";


        const availability =
            vehicle.available
                ? `<span class="badge bg-success">
                    Available
                   </span>`
                : `<span class="badge bg-danger">
                    Unavailable
                   </span>`;


        container.innerHTML = `

            <div class="row">

                <div class="col-md-7">

                    <img
                        src="${image}"
                        class="vehicle-details-image"
                        alt="${vehicle.name}">

                </div>


                <div class="col-md-5">

                    <h2>
                        ${vehicle.name}
                    </h2>

                    <p>
                        <strong>Type:</strong>
                        ${vehicle.type}
                    </p>

                    <p>
                        <strong>Location:</strong>
                        ${vehicle.location}
                    </p>

                    <p>
                        <strong>Registration:</strong>
                        ${vehicle.registrationNumber}
                    </p>

                    <p>
                        ${vehicle.description || ""}
                    </p>

                    <p>
                        <strong>Features:</strong>
                        ${vehicle.features || "Not specified"}
                    </p>

                    <p class="price">
                        ₹${vehicle.dailyPrice} / day
                    </p>

                    <p>
                        ${availability}
                    </p>

                    ${
                        vehicle.available
                        ?
                        `<a
                            href="#bookingBox"
                            class="btn btn-primary">
                            Book Vehicle
                         </a>`
                        :
                        ""
                    }

                </div>

            </div>


            <hr class="my-5">


            <div class="booking-box" id="bookingBox">

                <h4>
                    Book This Vehicle
                </h4>

                <div id="bookingMessage"></div>

                <form id="bookingForm">

                    <div class="row">

                        <div class="col-md-6">

                            <label class="form-label">
                                Start Date
                            </label>

                            <input
                                type="date"
                                id="startDate"
                                class="form-control"
                                required>

                        </div>


                        <div class="col-md-6">

                            <label class="form-label">
                                End Date
                            </label>

                            <input
                                type="date"
                                id="endDate"
                                class="form-control"
                                required>

                        </div>

                    </div>


                    <button
                        type="submit"
                        class="btn btn-success mt-3">

                        Book Vehicle

                    </button>

                </form>

            </div>


            <hr class="my-5">


            <h4>
                Reviews
            </h4>

            <div id="reviews"></div>

        `;


        document
            .getElementById("bookingForm")
            .addEventListener(
                "submit",
                createBooking
            );


        loadReviews();

    }

    catch (error) {

        container.innerHTML =
            `<div class="alert alert-danger">
                Unable to load vehicle.
            </div>`;
    }
}


async function createBooking(event) {

    event.preventDefault();


    if (!requireLogin()) {
        return;
    }


    if (getUserRole() !== "CUSTOMER") {

        alert("Only customers can book vehicles.");

        return;
    }


    const startDate =
        document.getElementById("startDate").value;

    const endDate =
        document.getElementById("endDate").value;


    const message =
        document.getElementById("bookingMessage");


    if (endDate < startDate) {

        message.innerHTML =
            `<div class="alert alert-danger">
                End date cannot be before start date.
            </div>`;

        return;
    }


    try {

        const response = await fetch(
            API_BASE_URL + "/bookings",
            {
                method: "POST",

                headers: getAuthHeaders(),

                body: JSON.stringify({
                    vehicleId: Number(vehicleId),
                    startDate: startDate,
                    endDate: endDate
                })
            }
        );


        const data =
            await response.json();


        if (response.ok) {

            message.innerHTML =
                `<div class="alert alert-success">
                    Booking created successfully.
                    Booking ID: ${data.id}
                </div>`;

        }

        else {

            message.innerHTML =
                `<div class="alert alert-danger">
                    ${data.message || "Booking failed."}
                </div>`;
        }

    }

    catch (error) {

        message.innerHTML =
            `<div class="alert alert-danger">
                Booking failed.
            </div>`;
    }
}


async function loadReviews() {

    const container =
        document.getElementById("reviews");


    try {

        const response =
            await fetch(
                API_BASE_URL +
                "/reviews/vehicle/" +
                vehicleId,
                {
                    headers: getAuthHeaders()
                }
            );


        const reviews =
            await response.json();


        if (reviews.length === 0) {

            container.innerHTML =
                `<p class="text-muted">
                    No reviews yet.
                </p>`;

            return;
        }


        container.innerHTML = "";


        reviews.forEach(review => {

            container.innerHTML += `

                <div class="review-box">

                    <div class="rating">
                        ${"★".repeat(review.rating)}
                        ${"☆".repeat(5 - review.rating)}
                    </div>

                    <p>
                        ${review.comment}
                    </p>

                    <small class="text-muted">
                        ${review.createdAt}
                    </small>

                </div>

            `;
        });

    }

    catch (error) {

        container.innerHTML =
            `<p>
                Unable to load reviews.
            </p>`;
    }
}


loadVehicle();