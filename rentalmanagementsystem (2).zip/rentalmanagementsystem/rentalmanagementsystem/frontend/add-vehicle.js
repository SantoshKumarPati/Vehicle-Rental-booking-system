if (!requireLogin()) {
    throw new Error("Not logged in");
}

if (getUserRole() !== "OWNER") {
    alert("Only owners can add vehicles.");
    window.location.href = "index.html";
}

const addVehicleForm =
    document.getElementById("vehicleForm");

const message =
    document.getElementById("message");


addVehicleForm.addEventListener(
    "submit",
    async function (event) {

        event.preventDefault();

        const name =
            document.getElementById("name")
                .value.trim();

        const description =
            document.getElementById("description")
                .value.trim();

        const image =
            document.getElementById("image")
                .value.trim();

        const type =
            document.getElementById("type")
                .value;

        const registrationNumber =
            document.getElementById("registrationNumber")
                .value.trim();

        const dailyPrice =
            document.getElementById("dailyPrice")
                .value;

        const location =
            document.getElementById("location")
                .value.trim();

        const features =
            document.getElementById("features")
                .value.trim();


        try {

            const response = await fetch(
                API_BASE_URL + "/vehicles",
                {
                    method: "POST",

                    headers: getAuthHeaders(),

                    body: JSON.stringify({

                        name: name,

                        description: description,

                        image: image,

                        type: type,

                        registrationNumber:
                            registrationNumber,

                        dailyPrice:
                            Number(dailyPrice),

                        location: location,

                        available: true,

                        features: features
                    })
                }
            );


            const data =
                await response.text();


            console.log(
                "STATUS:",
                response.status
            );

            console.log(
                "RESPONSE:",
                data
            );


            if (response.ok) {

                message.innerHTML =
                    `<div class="alert alert-success">
                        Vehicle added successfully.
                        <br>
                        Server Response: ${data}
                    </div>`;

            }
            else {

                message.innerHTML =
                    `<div class="alert alert-danger">
                        Error ${response.status}
                        <br>
                        ${data}
                    </div>`;
            }


        }
        catch (error) {

            console.error(
                "FETCH ERROR:",
                error
            );

            message.innerHTML =
                `<div class="alert alert-danger">
                    ${error.message}
                </div>`;
        }

    }
);