async function loadBookings() {

    if (!requireLogin()) {
        return;
    }


    const role =
        getUserRole();


    let url;


    if (role === "OWNER") {

        url =
            API_BASE_URL +
            "/bookings/owner";

        document.getElementById("pageTitle")
            .textContent = "Owner Bookings";

    }

    else {

        url =
            API_BASE_URL +
            "/bookings/my";

        document.getElementById("pageTitle")
            .textContent = "My Bookings";
    }


    try {

        const response =
            await fetch(
                url,
                {
                    headers: getAuthHeaders()
                }
            );


        const bookings =
            await response.json();


        if (!response.ok) {
            throw new Error();
        }


        displayBookings(bookings);

    }

    catch (error) {

        document.getElementById("message").innerHTML =
            `<div class="alert alert-danger">
                Unable to load bookings.
            </div>`;
    }
}


function displayBookings(bookings) {

    const table =
        document.getElementById("bookingTable");


    table.innerHTML = "";


    if (bookings.length === 0) {

        table.innerHTML =
            `<tr>
                <td colspan="7"
                    class="text-center">
                    No bookings found.
                </td>
            </tr>`;

        return;
    }


    bookings.forEach(booking => {

        let action = "";


        if (getUserRole() === "CUSTOMER") {

            if (
                booking.status === "PENDING" ||
                booking.status === "APPROVED"
            ) {

                action =
                    `<button
                        class="btn btn-sm btn-danger"
                        onclick="cancelBooking(${booking.id})">

                        Cancel

                    </button>`;
            }

        }


        if (getUserRole() === "OWNER") {

            if (booking.status === "PENDING") {

                action = `

                    <button
                        class="btn btn-sm btn-success me-1"
                        onclick="updateBooking(${booking.id}, 'approve')">

                        Approve

                    </button>

                    <button
                        class="btn btn-sm btn-danger"
                        onclick="updateBooking(${booking.id}, 'reject')">

                        Reject

                    </button>

                `;
            }

            else if (booking.status === "APPROVED") {

                action =
                    `<button
                        class="btn btn-sm btn-primary"
                        onclick="updateBooking(${booking.id}, 'handover')">

                        Handover

                    </button>`;
            }

            else if (booking.status === "HANDED_OVER") {

                action =
                    `<button
                        class="btn btn-sm btn-success"
                        onclick="updateBooking(${booking.id}, 'return')">

                        Return

                    </button>`;
            }
        }


        table.innerHTML += `

            <tr>

                <td>${booking.id}</td>

                <td>${booking.startDate}</td>

                <td>${booking.endDate}</td>

                <td>${booking.totalDays}</td>

                <td>₹${booking.totalCost}</td>

                <td>
                    <span class="badge bg-secondary">
                        ${booking.status}
                    </span>
                </td>

                <td>
                    ${action}
                </td>

            </tr>

        `;
    });
}


async function cancelBooking(id) {

    if (!confirm("Cancel this booking?")) {
        return;
    }


    try {

        const response =
            await fetch(
                API_BASE_URL +
                "/bookings/" +
                id +
                "/cancel",
                {
                    method: "PUT",
                    headers: getAuthHeaders()
                }
            );


        if (response.ok) {

            alert("Booking cancelled.");

            loadBookings();

        }

        else {

            alert("Unable to cancel booking.");
        }

    }

    catch (error) {

        alert("Request failed.");
    }
}


async function updateBooking(id, action) {

    const response =
        await fetch(
            API_BASE_URL +
            "/bookings/" +
            id +
            "/" +
            action,
            {
                method: "PUT",
                headers: getAuthHeaders()
            }
        );


    if (response.ok) {

        alert(
            "Booking updated successfully."
        );

        loadBookings();

    }

    else {

        alert(
            "Unable to update booking."
        );
    }
}


loadBookings();