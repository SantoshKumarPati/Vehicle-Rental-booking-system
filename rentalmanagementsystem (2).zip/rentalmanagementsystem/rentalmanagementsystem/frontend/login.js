const loginForm =
    document.getElementById("loginForm");


loginForm.addEventListener("submit", async function (event) {

    event.preventDefault();


    const email =
        document.getElementById("email").value.trim();

    const password =
        document.getElementById("password").value;

    const message =
        document.getElementById("message");


    try {

        const response = await fetch(
            API_BASE_URL + "/auth/login",
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify({
                    email: email,
                    password: password
                })
            }
        );


        const data = await response.json();


        if (response.ok) {

            localStorage.setItem(
                "token",
                data.token
            );

            localStorage.setItem(
                "name",
                data.name
            );

            localStorage.setItem(
                "email",
                data.email
            );

            localStorage.setItem(
                "role",
                data.role
            );


            if (data.role === "OWNER") {

                window.location.href =
                    "owner-dashboard.html";

            }

            else {

                window.location.href =
                    "customer-dashboard.html";
            }

        }

        else {

            message.innerHTML =
                `<div class="alert alert-danger">
                    Login failed.
                    Please check your email and password.
                </div>`;
        }

    }

    catch (error) {

        message.innerHTML =
            `<div class="alert alert-danger">
                Cannot connect to backend.
            </div>`;
    }

});