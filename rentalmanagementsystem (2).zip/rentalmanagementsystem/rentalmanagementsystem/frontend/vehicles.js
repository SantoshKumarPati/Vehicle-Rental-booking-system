if (!requireLogin()) {
    throw new Error("User is not logged in");
}

const vehicleContainer =
    document.getElementById("vehicleContainer");

const searchForm =
    document.getElementById("searchForm");


async function loadVehicles(url) {

    try {

        const response = await fetch(
            url,
            {
                method: "GET",
                headers: getAuthHeaders()
            }
        );

        const data =
            await response.text();

        console.log(
            "Status:",
            response.status
        );

        console.log(
            "Response:",
            data
        );


        if (!response.ok) {

            vehicleContainer.innerHTML =
                `<div class="alert alert-danger">
                    Error ${response.status}: ${data}
                </div>`;

            return;
        }


        const vehicles =
            JSON.parse(data);

        displayVehicles(vehicles);


    }
    catch (error) {

        console.error(
            "FETCH ERROR:",
            error
        );

        vehicleContainer.innerHTML =
            `<div class="alert alert-danger">
                ${error.message}
            </div>`;
    }
}


function displayVehicles(vehicles) {

    vehicleContainer.innerHTML = "";


    if (!vehicles ||
        vehicles.length === 0) {

        vehicleContainer.innerHTML =
            `<div class="alert alert-warning">
                No vehicles found.
            </div>`;

        return;
    }


    vehicles.forEach(
        function (vehicle) {

            const image =
                vehicle.image &&
                vehicle.image.trim() !== ""
                    ? vehicle.image
                    : "https://via.placeholder.com/600x400?text=Vehicle";


            const availability =
                vehicle.available
                    ? `<span class="badge bg-success">
                            Available
                       </span>`
                    : `<span class="badge bg-danger">
                            Unavailable
                       </span>`;


            const card =
                document.createElement("div");


            card.className =
                "col-md-4 mb-4";


            card.innerHTML = `

                <div class="card vehicle-card shadow-sm">

                    <img
                        src="${image}"
                        class="card-img-top vehicle-image"
                        alt="${vehicle.name}"
                    >

                    <div class="card-body">

                        <h5 class="card-title">
                            ${vehicle.name}
                        </h5>

                        <p class="text-muted">
                            ${vehicle.type}
                        </p>

                        <p>
                            ${vehicle.description || ""}
                        </p>

                        <p>
                            <strong>Location:</strong>
                            ${vehicle.location}
                        </p>

                        <p class="price">
                            ₹${vehicle.dailyPrice} / day
                        </p>

                        <p>
                            ${availability}
                        </p>

                        <a
                            href="vehicle-details.html?id=${vehicle.id}"
                            class="btn btn-primary"
                        >
                            View Details
                        </a>

                    </div>

                </div>

            `;


            vehicleContainer.appendChild(card);
        }
    );
}


if (searchForm) {

    searchForm.addEventListener(
        "submit",
        function (event) {

            event.preventDefault();


            const name =
                document.getElementById("name")
                    .value.trim();


            const type =
                document.getElementById("type")
                    .value;


            const location =
                document.getElementById("location")
                    .value.trim();


            const minPrice =
                document.getElementById("minPrice")
                    .value;


            const maxPrice =
                document.getElementById("maxPrice")
                    .value;


            const params =
                new URLSearchParams();


            if (name !== "") {

                params.append(
                    "name",
                    name
                );
            }


            if (type !== "") {

                params.append(
                    "type",
                    type
                );
            }


            if (location !== "") {

                params.append(
                    "location",
                    location
                );
            }


            if (minPrice !== "") {

                params.append(
                    "minPrice",
                    minPrice
                );
            }


            if (maxPrice !== "") {

                params.append(
                    "maxPrice",
                    maxPrice
                );
            }


            let url =
                API_BASE_URL +
                "/vehicles/search";


            if (params.toString() !== "") {

                url +=
                    "?" +
                    params.toString();
            }


            loadVehicles(url);
        }
    );
}


loadVehicles(
    API_BASE_URL + "/vehicles"
);