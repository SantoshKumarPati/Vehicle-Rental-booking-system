async function loadCustomerDashboard() {

    if (!requireLogin()) {
        return;
    }


    if (getUserRole() !== "CUSTOMER") {

        alert("Customer access only.");

        openDashboard();

        return;
    }


    document.getElementById("customerName")
        .textContent = getUserName();


    try {

        const response =
            await fetch(
                API_BASE_URL +
                "/dashboard/customer",
                {
                    headers: getAuthHeaders()
                }
            );


        const data =
            await response.json();


        if (!response.ok) {
            throw new Error();
        }


        document.getElementById("totalBookings")
            .textContent = data.totalBookings;

        document.getElementById("upcomingBookings")
            .textContent = data.upcomingBookings;

        document.getElementById("completedBookings")
            .textContent = data.completedBookings;

        document.getElementById("cancelledBookings")
            .textContent = data.cancelledBookings;

    }

    catch (error) {

        document.getElementById("message").innerHTML =
            `<div class="alert alert-danger">
                Unable to load dashboard.
            </div>`;
    }
}


loadCustomerDashboard();