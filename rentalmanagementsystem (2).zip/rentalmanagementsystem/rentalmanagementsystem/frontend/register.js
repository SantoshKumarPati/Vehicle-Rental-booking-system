const registerForm = document.getElementById("registerForm");

registerForm.addEventListener("submit", async function (event) {
    event.preventDefault();

    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    const role = document.getElementById("role").value;
    const message = document.getElementById("message");

    try {
        const response = await fetch(
            "http://127.0.0.1:8081/api/auth/register",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    name: name,
                    email: email,
                    password: password,
                    role: role
                })
            }
        );

        const data = await response.text();

        console.log("Status:", response.status);
        console.log("Response:", data);

        if (response.ok) {
            message.innerHTML =
                `<div class="alert alert-success">
                    Registration successful.
                    <a href="login.html">Login now</a>
                </div>`;

            registerForm.reset();

        } else {
            message.innerHTML =
                `<div class="alert alert-danger">
                    Server Error: ${response.status}<br>
                    ${data}
                </div>`;
        }

    } catch (error) {

        console.error("FETCH ERROR:", error);

        message.innerHTML =
            `<div class="alert alert-danger">
                ${error.message}
            </div>`;
    }
});