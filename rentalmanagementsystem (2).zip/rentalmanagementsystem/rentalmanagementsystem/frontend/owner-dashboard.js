async function loadOwnerDashboard() {

    if (!requireLogin()) {
        return;
    }


    if (getUserRole() !== "OWNER") {

        alert("Owner access only.");

        openDashboard();

        return;
    }


    document.getElementById("ownerName")
        .textContent = getUserName();


    try {

        const response =
            await fetch(
                API_BASE_URL +
                "/dashboard/owner",
                {
                    headers: getAuthHeaders()
                }
            );


        const data =
            await response.json();


        if (!response.ok) {
            throw new Error();
        }


        document.getElementById("totalVehicles")
            .textContent = data.totalVehicles;

        document.getElementById("totalBookings")
            .textContent = data.totalBookings;

        document.getElementById("pendingBookings")
            .textContent = data.pendingBookings;

        document.getElementById("completedBookings")
            .textContent = data.completedBookings;

    }

    catch (error) {

        document.getElementById("message").innerHTML =
            `<div class="alert alert-danger">
                Unable to load dashboard.
            </div>`;
    }
}


loadOwnerDashboard();